#!/bin/sh
#****************************************************************#
# ScriptName: myawr.sh
# Create Date: 2014-08-19 17:23
# Modify Date: 2014-08-19 17:23
#***************************************************************#
/usr/bin/perl /usr/local/dbadmin/monitor/mysqlawr.pl -u dbread -p db34379ad8TTd2332adsfread -lh 10.128.6.21 -P 3309  -tu dbmon -tp dbmon -TP 3310 -th 10.128.6.21 -n bond0 -d sdb -I 1
